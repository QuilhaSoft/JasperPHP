<?php

namespace JasperPHP\database;

/**
 * ADO Exception class.
 *
 * This class provides a custom exception for the ADO layer of JasperPHP.
 */
class Exception extends \Exception {}
