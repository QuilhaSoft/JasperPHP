<?php

namespace JasperPHP\exception;

/**
 * JasperPHP Exception class.
 *
 * This class provides a custom exception for the JasperPHP library.
 */
class Exception extends \Exception {}
