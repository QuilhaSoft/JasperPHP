<?php
namespace JasperPHP\elements;

use JasperPHP\elements\Element;

/**
 * SubreportParameter class
 * This class represents a subreport parameter element in a Jasper report.
 */
class SubreportParameter extends Element
{
	
	
	public function generate($dbData = null)
	{
		parent::generate($dbData);
	}
}
?>