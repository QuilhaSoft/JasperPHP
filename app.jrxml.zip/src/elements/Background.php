<?php
namespace JasperPHP\elements;


/**
 * Background class
 * This class represents the background band in a Jasper report.
 */
class Background extends Element
{
    
}
?>