<?php
namespace JasperPHP\elements;

use JasperPHP\elements\Element;
/**
 * SubreportParameterExpression class
 * This class represents a subreport parameter expression element in a Jasper report.
 */
class SubreportParameterExpression extends Element
{
	public function generate($obj = null)
	{
		parent::generate($obj);
	}
}
?>