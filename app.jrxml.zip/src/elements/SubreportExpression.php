<?php
namespace JasperPHP\elements;

use JasperPHP\elements\Element;

/**
 * SubreportExpression class
 * This class represents a subreport expression element in a Jasper report.
 */
class SubreportExpression extends Element
{
	
	
	public function generate($dbData = null)
	{
		parent::generate($dbData);
	}
}
?>